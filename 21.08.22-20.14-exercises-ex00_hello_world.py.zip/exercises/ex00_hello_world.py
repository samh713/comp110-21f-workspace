"""My first program for COMP110"""

__author__="7305-30379"
print("I woke up and I said, hello world.")